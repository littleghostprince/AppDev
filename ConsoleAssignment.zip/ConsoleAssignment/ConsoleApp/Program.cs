﻿using System;
using ConsoleLibrary;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleIO.Hello();
            Console.ReadLine();
            //Console.WriteLine("Hello World!");
        }
    }
}
