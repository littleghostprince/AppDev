﻿using System;

namespace ConsoleLibrary
{
    public class ConsoleIO
    {
        public static void Hello()
        {
            Console.WriteLine("Hello Library.");
        }
    }
}
